Hello, my name is DETRAX, and today i decided to post this ip grabber that i coded, it use
discord webhook to receive the target's info. Its easy to use. please follow the instructions:

#Linux:
git clone 

on cmd, type: pip install -r requirements.txt

don't forget to put your webhook on it !

#Windows
Download the repositorie

on cmd, type py -m pip install -r requirements.txt 

don't forget to put your webhook on it !

et voila !

if you need any help, any question, any request, please add me on discord: chahine07.